package com.pulseproxy

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val BgDark = Color(0xFF0A0F1A)
private val CardDark = Color(0xFF131B2E)
private val CardBorder = Color(0xFF1F2B46)
private val AccentTeal = Color(0xFF2DD4BF)
private val AccentBlue = Color(0xFF38BDF8)
private val AccentGreen = Color(0xFF10B981)
private val AccentAmber = Color(0xFFF59E0B)
private val AccentRed = Color(0xFFF43F5E)
private val TextPrimary = Color(0xFFF8FAFC)
private val TextMuted = Color(0xFF94A3B8)

class MainActivity : ComponentActivity() {

    private val notifLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = BgDark,
                    surface = CardDark,
                    primary = AccentTeal,
                    secondary = AccentBlue,
                    onBackground = TextPrimary,
                    onSurface = TextPrimary
                )
            ) {
                PulseProxyApp()
            }
        }
    }
}

@Composable
fun PulseProxyApp() {
    val context = LocalContext.current
    val stats by ProxyStateStore.stats.collectAsState()
    val logs by ProxyStateStore.logs.collectAsState()
    var config by remember { mutableStateOf(ProxyService.loadConfig(context)) }
    var selectedTab by remember { mutableIntStateOf(0) }

    Scaffold(
        containerColor = BgDark,
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF0F1626),
                tonalElevation = 0.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Rounded.Bolt, contentDescription = null) },
                    label = { Text("Прокси") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BgDark,
                        selectedTextColor = AccentTeal,
                        indicatorColor = AccentTeal,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Rounded.Settings, contentDescription = null) },
                    label = { Text("Настройки") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BgDark,
                        selectedTextColor = AccentTeal,
                        indicatorColor = AccentTeal,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Rounded.Terminal, contentDescription = null) },
                    label = { Text("Логи") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = BgDark,
                        selectedTextColor = AccentTeal,
                        indicatorColor = AccentTeal,
                        unselectedIconColor = TextMuted,
                        unselectedTextColor = TextMuted
                    )
                )
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (selectedTab) {
                0 -> DashboardScreen(
                    stats = stats,
                    config = config,
                    onToggle = {
                        val intent = Intent(context, ProxyService::class.java).apply {
                            action = if (stats.isRunning) ProxyService.ACTION_STOP else ProxyService.ACTION_START
                        }
                        if (stats.isRunning) {
                            context.startService(intent)
                        } else {
                            context.startForegroundService(intent)
                        }
                    },
                    onResetSockets = {
                        ProxyService.engine.resetAllConnections("Ручной сброс")
                        Toast.makeText(context, "Сокеты сброшены", Toast.LENGTH_SHORT).show()
                    },
                    onRunTest = {
                        ProxyService.engine.runDiagnostics(config)
                    },
                    onOpenTelegram = { openInTelegram(context, config) }
                )
                1 -> SettingsScreen(
                    config = config,
                    isRunning = stats.isRunning,
                    onSave = { newCfg ->
                        config = newCfg
                        ProxyService.saveConfig(context, newCfg)
                        if (stats.isRunning) {
                            val i = Intent(context, ProxyService::class.java).setAction(ProxyService.ACTION_RESTART)
                            context.startForegroundService(i)
                        }
                        Toast.makeText(context, "Настройки применены", Toast.LENGTH_SHORT).show()
                    }
                )
                2 -> LogsScreen(
                    logs = logs,
                    onCopy = {
                        val text = logs.joinToString("\n") { "[${it.time}] ${it.level}: ${it.message}" }
                        copyToClipboard(context, "PulseProxy Logs", text)
                    },
                    onClear = { ProxyStateStore.clearLogs() }
                )
            }
        }
    }
}

@Composable
fun DashboardScreen(
    stats: ProxyStats,
    config: ProxyConfig,
    onToggle: () -> Unit,
    onResetSockets: () -> Unit,
    onRunTest: () -> Unit,
    onOpenTelegram: () -> Unit
) {
    val ringColor by animateColorAsState(
        targetValue = if (stats.isRunning) AccentTeal else Color(0xFF334155),
        label = "ringColor"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("PulseProxy v1.2.1", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text(
                    text = if (stats.isRunning) "Активен • 127.0.0.1:${config.port}" else "Остановлен",
                    fontSize = 13.sp,
                    color = if (stats.isRunning) AccentTeal else TextMuted
                )
            }
            if (stats.isRunning) {
                FilledTonalIconButton(
                    onClick = onResetSockets,
                    colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = CardDark)
                ) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Сбросить сокеты", tint = AccentBlue)
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = CardDark),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 26.dp, horizontal = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(134.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(ringColor.copy(alpha = 0.25f), Color.Transparent)
                            )
                        )
                        .border(3.dp, ringColor, CircleShape)
                        .clickable { onToggle() },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Rounded.PowerSettingsNew,
                            contentDescription = "Включить/выключить",
                            tint = if (stats.isRunning) AccentTeal else TextPrimary,
                            modifier = Modifier.size(46.dp)
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = if (stats.isRunning) "ВКЛЮЧЁН" else "ЗАПУСТИТЬ",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (stats.isRunning) AccentTeal else TextMuted
                        )
                    }
                }

                Text(
                    text = stats.lastRoute,
                    fontSize = 13.sp,
                    color = TextMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    MetricChip("Пинг", stats.lastPingMs?.let { "${it} мс" } ?: "—")
                    MetricChip("Сокеты", "${stats.activeConnections}")
                    MetricChip("Трафик", formatBytes(stats.bytesUp + stats.bytesDown))
                }

                Button(
                    onClick = onOpenTelegram,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AccentTeal,
                        contentColor = BgDark
                    )
                ) {
                    Icon(Icons.Rounded.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Подключить в Telegram", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = CardDark),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Speed, contentDescription = null, tint = AccentBlue)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Проверка работы",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(
                        onClick = onRunTest,
                        enabled = !stats.diagnosticsRunning,
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                        border = BorderStroke(1.dp, AccentBlue.copy(alpha = 0.5f))
                    ) {
                        if (stats.diagnosticsRunning) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                strokeWidth = 2.dp,
                                color = AccentBlue
                            )
                            Spacer(Modifier.width(6.dp))
                        }
                        Text(
                            text = if (stats.diagnosticsRunning) "Тест..." else "Проверить",
                            color = AccentBlue,
                            fontSize = 13.sp,
                            maxLines = 1,
                            softWrap = false
                        )
                    }
                }

                if (stats.diagnostics.isEmpty()) {
                    Text(
                        "Нажми «Проверить», чтобы протестировать Cloudflare Worker (медиа DC4), прямой WebSocket и обход DNS.",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                } else {
                    stats.diagnostics.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFF0E1525))
                                .padding(horizontal = 12.dp, vertical = 9.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val (icon, tint) = when (item.status) {
                                    DiagStatus.OK -> Icons.Rounded.CheckCircle to AccentGreen
                                    DiagStatus.WARN -> Icons.Rounded.WarningAmber to AccentAmber
                                    DiagStatus.FAIL -> Icons.Rounded.ErrorOutline to AccentRed
                                    DiagStatus.PENDING -> Icons.Rounded.Wifi to TextMuted
                                }
                                Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text(item.name, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                    Text(item.detail, fontSize = 11.sp, color = TextMuted)
                                }
                            }
                            if (item.latencyMs != null) {
                                Text(
                                    "${item.latencyMs} мс",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AccentTeal
                                )
                            }
                        }
                    }

                    stats.diagnosticVerdict?.let { verdict ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(AccentBlue.copy(alpha = 0.12f))
                                .padding(12.dp)
                        ) {
                            Text(verdict, fontSize = 12.sp, color = TextPrimary, lineHeight = 17.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricChip(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Text(label, fontSize = 11.sp, color = TextMuted)
    }
}

@Composable
fun SettingsScreen(
    config: ProxyConfig,
    isRunning: Boolean,
    onSave: (ProxyConfig) -> Unit
) {
    var portText by remember(config) { mutableStateOf(config.port.toString()) }
    var secretText by remember(config) { mutableStateOf(config.secretHex) }
    var routeMode by remember(config) { mutableStateOf(config.routeMode) }
    var workerHost by remember(config) { mutableStateOf(config.customWorkerHost) }
    var workerDisableTls by remember(config) { mutableStateOf(config.workerDisableTls) }
    var autoReset by remember(config) { mutableStateOf(config.autoResetOnNetworkChange) }
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Настройки", fontSize = 24.sp, fontWeight = FontWeight.Bold)

        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = CardDark),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Обход через Cloudflare Worker", fontWeight = FontWeight.SemiBold, color = AccentTeal)

                OutlinedTextField(
                    value = workerHost,
                    onValueChange = { workerHost = it.trim() },
                    label = { Text("Домен твоего Worker") },
                    placeholder = { Text("tg-proxy.username.workers.dev") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Без TLS для Worker (ws:// порт 80)", fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text("Включи, если провайдер режет HTTPS к workers.dev", fontSize = 11.5.sp, color = TextMuted)
                    }
                    Switch(checked = workerDisableTls, onCheckedChange = { workerDisableTls = it })
                }
            }
        }

        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = CardDark),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Локальный прокси", fontWeight = FontWeight.SemiBold, color = AccentTeal)

                OutlinedTextField(
                    value = portText,
                    onValueChange = { portText = it.filter { ch -> ch.isDigit() }.take(5) },
                    label = { Text("Локальный порт (по умолчанию 1443)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = secretText,
                    onValueChange = { secretText = it.trim() },
                    label = { Text("MTProto секрет (dd + 32 hex)") },
                    singleLine = true,
                    trailingIcon = {
                        IconButton(onClick = { secretText = MtProtoCrypto.generateRandomSecret() }) {
                            Icon(Icons.Rounded.Refresh, contentDescription = "Новый секрет", tint = AccentTeal)
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = CardDark),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Режим маршрутизации", fontWeight = FontWeight.SemiBold, color = AccentTeal)
                RouteMode.entries.forEach { mode ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (routeMode == mode) AccentTeal.copy(alpha = 0.14f) else Color(0xFF0E1525))
                            .clickable { routeMode = mode }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = routeMode == mode, onClick = { routeMode = mode })
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(mode.title, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                            Text(mode.subtitle, fontSize = 12.sp, color = TextMuted)
                        }
                    }
                }
            }
        }

        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = CardDark),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Автосброс при смене сети", fontWeight = FontWeight.Medium)
                    Text("Мгновенно закрывает зависшие сокеты при Wi-Fi ↔ 4G", fontSize = 12.sp, color = TextMuted)
                }
                Switch(checked = autoReset, onCheckedChange = { autoReset = it })
            }
        }

        Button(
            onClick = {
                val parsedPort = portText.toIntOrNull()?.coerceIn(1024, 65535) ?: 1443
                try {
                    MtProtoCrypto.parseSecret(secretText)
                    onSave(
                        ProxyConfig(
                            port = parsedPort,
                            secretHex = secretText,
                            routeMode = routeMode,
                            customWorkerHost = workerHost,
                            workerDisableTls = workerDisableTls,
                            autoResetOnNetworkChange = autoReset
                        )
                    )
                } catch (e: Exception) {
                    Toast.makeText(context, e.message ?: "Ошибка секрета", Toast.LENGTH_LONG).show()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AccentTeal, contentColor = BgDark)
        ) {
            Text(
                if (isRunning) "Сохранить и перезапустить" else "Сохранить настройки",
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun LogsScreen(
    logs: List<LogEntry>,
    onCopy: () -> Unit,
    onClear: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Логи событий", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Row {
                IconButton(onClick = onCopy) {
                    Icon(Icons.Rounded.ContentCopy, contentDescription = "Скопировать", tint = AccentBlue)
                }
                IconButton(onClick = onClear) {
                    Icon(Icons.Rounded.DeleteOutline, contentDescription = "Очистить", tint = TextMuted)
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxSize(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0C1220)),
            border = BorderStroke(1.dp, CardBorder)
        ) {
            if (logs.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Логов пока нет. Запусти прокси или проверку связи.", color = TextMuted, fontSize = 13.sp)
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(logs.reversed()) { entry ->
                        val color = when (entry.level) {
                            "OK" -> AccentGreen
                            "WARN" -> AccentAmber
                            "ERR" -> AccentRed
                            else -> AccentBlue
                        }
                        Text(
                            text = "[${entry.time}] ${entry.level}  ${entry.message}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.5.sp,
                            color = color,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}

private fun openInTelegram(context: Context, config: ProxyConfig) {
    val uri = Uri.parse("tg://proxy?server=127.0.0.1&port=${config.port}&secret=${config.secretHex}")
    val intent = Intent(Intent.ACTION_VIEW, uri)
    try {
        context.startActivity(intent)
    } catch (_: Exception) {
        copyToClipboard(context, "TG Proxy Link", uri.toString())
        Toast.makeText(context, "Ссылка скопирована — отправь её в «Избранное» в Telegram", Toast.LENGTH_LONG).show()
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText(label, text))
    Toast.makeText(context, "Скопировано в буфер", Toast.LENGTH_SHORT).show()
}

private fun formatBytes(bytes: Long): String {
    return when {
        bytes < 1024 -> "$bytes Б"
        bytes < 1024 * 1024 -> "${bytes / 1024} КБ"
        else -> String.format(Locale.US, "%.1f МБ", bytes / (1024.0 * 1024.0))
    }
}
