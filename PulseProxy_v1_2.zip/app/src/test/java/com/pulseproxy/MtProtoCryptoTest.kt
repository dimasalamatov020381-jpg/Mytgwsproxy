package com.pulseproxy

import org.junit.Assert.*
import org.junit.Test
import java.security.SecureRandom

class MtProtoCryptoTest {

    @Test
    fun handshakeAndCipherRoundTripWorks() {
        val secretHex = MtProtoCrypto.generateRandomSecret()
        assertTrue(secretHex.startsWith("dd"))
        assertEquals(34, secretHex.length)

        val secret16 = MtProtoCrypto.parseSecret(secretHex)
        assertEquals(16, secret16.size)

        val clientInit = ByteArray(64).also { SecureRandom().nextBytes(it) }
        val protoTag = byteArrayOf(0xdd.toByte(), 0xdd.toByte(), 0xdd.toByte(), 0xdd.toByte())
        System.arraycopy(protoTag, 0, clientInit, 56, 4)
        clientInit[60] = 4
        clientInit[61] = 0

        val encKey = MtProtoCrypto.sha256(clientInit.copyOfRange(8, 40), secret16)
        val encIv = clientInit.copyOfRange(40, 56)
        val rev = clientInit.copyOfRange(8, 56).reversedArray()
        val decKey = MtProtoCrypto.sha256(rev.copyOfRange(0, 32), secret16)
        val decIv = rev.copyOfRange(32, 48)

        val clientOutCipher = AesCtr(encKey, encIv)
        val clientInCipher = AesCtr(decKey, decIv)

        val encInit = clientOutCipher.update(clientInit)
        val wireInit = clientInit.copyOf()
        System.arraycopy(encInit, 56, wireInit, 56, 8)

        val parsed = MtProtoCrypto.parseClientHandshake(wireInit, secret16)
        assertNotNull("Handshake должен успешно распарситься", parsed)
        assertEquals(4, parsed!!.dcId)
        assertFalse(parsed.isMedia)

        val samplePayload = "MTProto test payload 12345".toByteArray()
        val wireToProxy = clientOutCipher.update(samplePayload)
        val decryptedAtProxy = parsed.clientDecrypt.update(wireToProxy)
        assertArrayEquals(samplePayload, decryptedAtProxy)

        val wireToClient = parsed.clientEncrypt.update(samplePayload)
        val decryptedAtClient = clientInCipher.update(wireToClient)
        assertArrayEquals(samplePayload, decryptedAtClient)

        val relay = MtProtoCrypto.buildRelayHandshake(parsed.protoTag, parsed.rawDcBytes)
        assertEquals(64, relay.initPacket.size)
    }

    @Test
    fun mediaDcNegativeAndCdn203AreDetected() {
        val secretHex = MtProtoCrypto.generateRandomSecret()
        val secret16 = MtProtoCrypto.parseSecret(secretHex)

        // DC = -2 (media DC2)
        val initMedia = ByteArray(64).also { SecureRandom().nextBytes(it) }
        val protoTag = byteArrayOf(0xee.toByte(), 0xee.toByte(), 0xee.toByte(), 0xee.toByte())
        System.arraycopy(protoTag, 0, initMedia, 56, 4)
        initMedia[60] = 0xFE.toByte()
        initMedia[61] = 0xFF.toByte()
        val encMedia = AesCtr(MtProtoCrypto.sha256(initMedia.copyOfRange(8, 40), secret16), initMedia.copyOfRange(40, 56)).update(initMedia)
        val wireMedia = initMedia.copyOf().also { System.arraycopy(encMedia, 56, it, 56, 8) }
        val parsedMedia = MtProtoCrypto.parseClientHandshake(wireMedia, secret16)
        assertNotNull(parsedMedia)
        assertEquals(2, parsedMedia!!.dcId)
        assertTrue(parsedMedia.isMedia)

        // DC = -203 (CDN media DC203): -203 in signed 16-bit LE = 0x35, 0xFF
        val initCdn = ByteArray(64).also { SecureRandom().nextBytes(it) }
        System.arraycopy(protoTag, 0, initCdn, 56, 4)
        initCdn[60] = 0x35.toByte()
        initCdn[61] = 0xFF.toByte()
        val encCdn = AesCtr(MtProtoCrypto.sha256(initCdn.copyOfRange(8, 40), secret16), initCdn.copyOfRange(40, 56)).update(initCdn)
        val wireCdn = initCdn.copyOf().also { System.arraycopy(encCdn, 56, it, 56, 8) }
        val parsedCdn = MtProtoCrypto.parseClientHandshake(wireCdn, secret16)
        assertNotNull(parsedCdn)
        assertEquals(203, parsedCdn!!.dcId)
        assertTrue(parsedCdn.isMedia)
    }
}
