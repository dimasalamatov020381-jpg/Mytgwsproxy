package com.pulseproxy

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat

class ProxyService : Service() {

    companion object {
        const val ACTION_START = "com.pulseproxy.START"
        const val ACTION_STOP = "com.pulseproxy.STOP"
        const val ACTION_RESTART = "com.pulseproxy.RESTART"
        const val ACTION_TEST = "com.pulseproxy.TEST"

        private const val CHANNEL_ID = "pulseproxy_channel"
        private const val NOTIF_ID = 1443

        val engine = MtProtoProxyEngine()

        fun loadConfig(context: Context): ProxyConfig {
            val prefs = context.getSharedPreferences("pulseproxy_prefs", Context.MODE_PRIVATE)
            var secret = prefs.getString("secret", null)
            if (secret.isNullOrBlank()) {
                secret = MtProtoCrypto.generateRandomSecret()
                prefs.edit().putString("secret", secret).apply()
            }
            val modeName = prefs.getString("route_mode", RouteMode.AUTO.name) ?: RouteMode.AUTO.name
            val mode = runCatching { RouteMode.valueOf(modeName) }.getOrDefault(RouteMode.AUTO)
            return ProxyConfig(
                port = prefs.getInt("port", 1443),
                secretHex = secret,
                routeMode = mode,
                customWorkerHost = prefs.getString("worker_host", "") ?: "",
                workerDisableTls = prefs.getBoolean("worker_no_tls", false),
                autoResetOnNetworkChange = prefs.getBoolean("auto_reset", true)
            )
        }

        fun saveConfig(context: Context, config: ProxyConfig) {
            context.getSharedPreferences("pulseproxy_prefs", Context.MODE_PRIVATE).edit()
                .putInt("port", config.port)
                .putString("secret", config.secretHex)
                .putString("route_mode", config.routeMode.name)
                .putString("worker_host", config.customWorkerHost)
                .putBoolean("worker_no_tls", config.workerDisableTls)
                .putBoolean("auto_reset", config.autoResetOnNetworkChange)
                .apply()
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var lastNetworkResetMs = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopProxyAndService()
                return START_NOT_STICKY
            }
            ACTION_RESTART -> {
                val cfg = loadConfig(this)
                startForegroundCompat(cfg)
                engine.stop()
                engine.start(cfg)
                registerNetworkWatcher(cfg)
                return START_STICKY
            }
            ACTION_TEST -> {
                engine.runDiagnostics(loadConfig(this))
                return if (engine.isRunning()) START_STICKY else START_NOT_STICKY
            }
            else -> {
                val cfg = loadConfig(this)
                startForegroundCompat(cfg)
                acquireWakeLock()
                engine.start(cfg)
                registerNetworkWatcher(cfg)
                return START_STICKY
            }
        }
    }

    private fun stopProxyAndService() {
        unregisterNetworkWatcher()
        releaseWakeLock()
        engine.stop()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        unregisterNetworkWatcher()
        releaseWakeLock()
        engine.stop()
        super.onDestroy()
    }

    private fun startForegroundCompat(config: ProxyConfig) {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val restartIntent = PendingIntent.getService(
            this, 1, Intent(this, ProxyService::class.java).setAction(ACTION_RESTART),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this, 2, Intent(this, ProxyService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_upload_done)
            .setContentTitle("PulseProxy v1.2 активен")
            .setContentText("127.0.0.1:${config.port} • ${config.routeMode.title}")
            .setOngoing(true)
            .setContentIntent(openIntent)
            .addAction(0, "Сбросить сокеты", restartIntent)
            .addAction(0, "Стоп", stopIntent)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Статус PulseProxy",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Постоянное уведомление для защиты прокси от усыпления Android"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PulseProxy::SocketLock").apply {
            acquire()
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        wakeLock = null
    }

    private fun registerNetworkWatcher(config: ProxyConfig) {
        unregisterNetworkWatcher()
        if (!config.autoResetOnNetworkChange) return

        val cm = getSystemService(ConnectivityManager::class.java)
        val req = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                val now = System.currentTimeMillis()
                if (now - lastNetworkResetMs > 2000L && engine.isRunning()) {
                    lastNetworkResetMs = now
                    engine.resetAllConnections("Смена сети")
                }
            }

            override fun onLost(network: Network) {
                if (engine.isRunning()) {
                    engine.resetAllConnections("Обрыв сети")
                }
            }
        }
        try {
            cm.registerNetworkCallback(req, cb)
            networkCallback = cb
        } catch (_: Exception) {
        }
    }

    private fun unregisterNetworkWatcher() {
        networkCallback?.let { cb ->
            try {
                getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(cb)
            } catch (_: Exception) {
            }
        }
        networkCallback = null
    }
}
