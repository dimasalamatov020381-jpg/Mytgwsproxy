package com.pulseproxy

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import okhttp3.*
import okio.ByteString
import java.io.InputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.security.MessageDigest
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec
import kotlin.math.abs

enum class RouteMode(val title: String, val subtitle: String) {
    AUTO("Авто (умный каскад)", "Worker (если задан) → Прямой WS → IP-обход → TCP"),
    WORKER_ONLY("Только Cloudflare Worker", "Весь трафик через твой личный домен workers.dev"),
    DIRECT_WS("Прямой WebSocket", "Прямые домены kws*.web.telegram.org без Worker")
}

data class ProxyConfig(
    val port: Int = 1443,
    val secretHex: String = MtProtoCrypto.generateRandomSecret(),
    val routeMode: RouteMode = RouteMode.AUTO,
    val customWorkerHost: String = "",
    val workerDisableTls: Boolean = false,
    val autoResetOnNetworkChange: Boolean = true
)

data class DiagnosticItem(
    val name: String,
    val status: DiagStatus,
    val detail: String,
    val latencyMs: Long? = null
)

enum class DiagStatus { PENDING, OK, WARN, FAIL }

data class LogEntry(
    val time: String,
    val level: String,
    val message: String
)

data class ProxyStats(
    val isRunning: Boolean = false,
    val activeConnections: Int = 0,
    val totalConnections: Long = 0,
    val bytesUp: Long = 0,
    val bytesDown: Long = 0,
    val lastRoute: String = "Ожидание подключения",
    val lastPingMs: Long? = null,
    val diagnosticsRunning: Boolean = false,
    val diagnostics: List<DiagnosticItem> = emptyList(),
    val diagnosticVerdict: String? = null
)

class AesCtr(key: ByteArray, iv: ByteArray) {
    private val cipher: Cipher = Cipher.getInstance("AES/CTR/NoPadding").apply {
        init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
    }

    fun update(input: ByteArray, offset: Int = 0, length: Int = input.size): ByteArray {
        if (length <= 0) return ByteArray(0)
        return cipher.update(input, offset, length) ?: ByteArray(0)
    }
}

data class ClientHandshake(
    val dcId: Int,
    val isMedia: Boolean,
    val rawDcBytes: ByteArray,
    val protoTag: ByteArray,
    val clientDecrypt: AesCtr,
    val clientEncrypt: AesCtr
)

data class RelayHandshake(
    val initPacket: ByteArray,
    val wsEncrypt: AesCtr,
    val wsDecrypt: AesCtr
)

object MtProtoCrypto {
    private val random = SecureRandom()

    private val TAG_ABRIDGED = byteArrayOf(0xef.toByte(), 0xef.toByte(), 0xef.toByte(), 0xef.toByte())
    private val TAG_INTERMEDIATE = byteArrayOf(0xee.toByte(), 0xee.toByte(), 0xee.toByte(), 0xee.toByte())
    private val TAG_PADDED = byteArrayOf(0xdd.toByte(), 0xdd.toByte(), 0xdd.toByte(), 0xdd.toByte())

    fun generateRandomSecret(): String {
        val bytes = ByteArray(16)
        random.nextBytes(bytes)
        return "dd" + bytes.joinToString("") { "%02x".format(it) }
    }

    fun parseSecret(raw: String): ByteArray {
        val clean = raw.trim().lowercase(Locale.US)
        val hex = when {
            clean.length == 34 && clean.startsWith("dd") -> clean.substring(2)
            clean.length == 32 -> clean
            else -> throw IllegalArgumentException("Секрет должен содержать 32 hex-символа (или dd + 32)")
        }
        return ByteArray(16) { i ->
            hex.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
    }

    fun sha256(a: ByteArray, b: ByteArray): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(a)
        md.update(b)
        return md.digest()
    }

    fun parseClientHandshake(init64: ByteArray, secret16: ByteArray): ClientHandshake? {
        if (init64.size != 64) return null

        val decKey = sha256(init64.copyOfRange(8, 40), secret16)
        val decIv = init64.copyOfRange(40, 56)

        val rev = init64.copyOfRange(8, 56).reversedArray()
        val encKey = sha256(rev.copyOfRange(0, 32), secret16)
        val encIv = rev.copyOfRange(32, 48)

        val clientDecrypt = AesCtr(decKey, decIv)
        val clientEncrypt = AesCtr(encKey, encIv)

        val decrypted = clientDecrypt.update(init64)
        val protoTag = decrypted.copyOfRange(56, 60)

        val validTag = protoTag.contentEquals(TAG_INTERMEDIATE) ||
            protoTag.contentEquals(TAG_PADDED) ||
            protoTag.contentEquals(TAG_ABRIDGED)
        if (!validTag) return null

        val lo = decrypted[60].toInt() and 0xFF
        val hi = decrypted[61].toInt()
        val rawDc = (hi shl 8) or lo
        val isMedia = rawDc < 0
        val absDc = abs(rawDc)
        val normalized = if (absDc > 10000) absDc - 10000 else absDc
        val dcId = if (normalized in 1..5) normalized else 2

        return ClientHandshake(
            dcId = dcId,
            isMedia = isMedia,
            rawDcBytes = decrypted.copyOfRange(60, 62),
            protoTag = protoTag,
            clientDecrypt = clientDecrypt,
            clientEncrypt = clientEncrypt
        )
    }

    fun buildRelayHandshake(protoTag: ByteArray, rawDcBytes: ByteArray): RelayHandshake {
        val init = ByteArray(64)
        while (true) {
            random.nextBytes(init)
            if (init[0] == 0xef.toByte()) continue
            val first4 = ((init[0].toInt() and 0xFF) shl 24) or
                ((init[1].toInt() and 0xFF) shl 16) or
                ((init[2].toInt() and 0xFF) shl 8) or
                (init[3].toInt() and 0xFF)
            val second4 = ((init[4].toInt() and 0xFF) shl 24) or
                ((init[5].toInt() and 0xFF) shl 16) or
                ((init[6].toInt() and 0xFF) shl 8) or
                (init[7].toInt() and 0xFF)
            if (second4 == 0) continue
            if (first4 == 0x48454144 || first4 == 0x504f5354 || first4 == 0x47455420 ||
                first4 == 0x4f505449 || first4 == 0x16030102 ||
                first4 == 0xeeeeeeee.toInt() || first4 == 0xdddddddd.toInt()
            ) continue
            break
        }

        System.arraycopy(protoTag, 0, init, 56, 4)
        System.arraycopy(rawDcBytes, 0, init, 60, 2)

        val wsEncKey = init.copyOfRange(8, 40)
        val wsEncIv = init.copyOfRange(40, 56)
        val rev = init.copyOfRange(8, 56).reversedArray()
        val wsDecKey = rev.copyOfRange(0, 32)
        val wsDecIv = rev.copyOfRange(32, 48)

        val wsEncrypt = AesCtr(wsEncKey, wsEncIv)
        val wsDecrypt = AesCtr(wsDecKey, wsDecIv)

        val encrypted = wsEncrypt.update(init)
        val outPacket = init.copyOf()
        System.arraycopy(encrypted, 56, outPacket, 56, 8)

        return RelayHandshake(outPacket, wsEncrypt, wsDecrypt)
    }
}

object ProxyStateStore {
    private val _stats = MutableStateFlow(ProxyStats())
    val stats: StateFlow<ProxyStats> = _stats.asStateFlow()

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    fun updateStats(block: (ProxyStats) -> ProxyStats) {
        _stats.update(block)
    }

    fun log(level: String, message: String) {
        val entry = LogEntry(timeFmt.format(Date()), level, message)
        _logs.update { current ->
            (current + entry).takeLast(250)
        }
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }
}

class MtProtoProxyEngine {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val running = AtomicBoolean(false)
    private var serverSocket: ServerSocket? = null
    private var acceptJob: Job? = null
    private var currentConfig = ProxyConfig()

    private val sessionIdGen = AtomicInteger(0)
    private val activeSessions = ConcurrentHashMap<Int, () -> Unit>()
    private val totalConnections = AtomicLong(0)
    private val bytesUp = AtomicLong(0)
    private val bytesDown = AtomicLong(0)

    private val routeCooldowns = ConcurrentHashMap<String, Long>()

    private val baseClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(3500, TimeUnit.MILLISECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .pingInterval(15, TimeUnit.SECONDS)
        .retryOnConnectionFailure(false)
        .build()

    private val dcDirectIps = mapOf(
        1 to listOf("149.154.175.53", "149.154.175.50"),
        2 to listOf("149.154.167.51", "149.154.167.220"),
        3 to listOf("149.154.175.100"),
        4 to listOf("149.154.167.220", "149.154.167.91"),
        5 to listOf("91.108.56.130")
    )

    fun isRunning(): Boolean = running.get()

    fun start(config: ProxyConfig) {
        if (running.getAndSet(true)) stop()
        running.set(true)
        currentConfig = config
        routeCooldowns.clear()

        val secret16 = try {
            MtProtoCrypto.parseSecret(config.secretHex)
        } catch (e: Exception) {
            ProxyStateStore.log("ERR", "Неверный секрет: ${e.message}")
            running.set(false)
            return
        }

        acceptJob = scope.launch {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress("127.0.0.1", config.port))
                serverSocket = ss

                ProxyStateStore.log("OK", "Сервер запущен на 127.0.0.1:${config.port} (${config.routeMode.title})")
                ProxyStateStore.updateStats {
                    it.copy(isRunning = true, lastRoute = "Готов к подключениям")
                }

                while (running.get() && !ss.isClosed) {
                    val client = try {
                        ss.accept()
                    } catch (_: Exception) {
                        break
                    }
                    client.tcpNoDelay = true
                    launch { handleClient(client, secret16, config) }
                }
            } catch (e: Exception) {
                ProxyStateStore.log("ERR", "Ошибка запуска порта ${config.port}: ${e.message}")
            } finally {
                running.set(false)
                ProxyStateStore.updateStats {
                    it.copy(isRunning = false, activeConnections = 0)
                }
            }
        }
    }

    fun stop() {
        running.set(false)
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        serverSocket = null
        acceptJob?.cancel()
        resetAllConnections("Остановка прокси")
        ProxyStateStore.updateStats {
            it.copy(isRunning = false, activeConnections = 0, lastRoute = "Остановлен")
        }
        ProxyStateStore.log("INFO", "Прокси остановлен")
    }

    fun resetAllConnections(reason: String) {
        routeCooldowns.clear()
        val count = activeSessions.size
        activeSessions.values.forEach { closeFn ->
            try {
                closeFn()
            } catch (_: Exception) {
            }
        }
        activeSessions.clear()
        ProxyStateStore.updateStats { it.copy(activeConnections = 0) }
        if (count > 0) {
            ProxyStateStore.log("WARN", "$reason: сброшено $count сокетов для быстрого реконнекта")
        }
    }

    private fun cleanWorkerHost(raw: String): String {
        return raw.trim()
            .removePrefix("https://")
            .removePrefix("http://")
            .removePrefix("wss://")
            .removePrefix("ws://")
            .substringBefore("/")
            .trim()
    }

    private sealed class UpstreamRoute(val key: String, val label: String) {
        class WebSocketRoute(
            key: String,
            label: String,
            val url: String,
            val fixedIp: String? = null,
            val isWorker: Boolean = false
        ) : UpstreamRoute(key, label)

        class DirectTcpRoute(
            key: String,
            label: String,
            val ip: String,
            val port: Int = 443
        ) : UpstreamRoute(key, label)
    }

    private fun buildRoutes(dcId: Int, isMedia: Boolean, config: ProxyConfig): List<UpstreamRoute> {
        val routes = mutableListOf<UpstreamRoute>()
        val primaryHost = if (isMedia) "kws$dcId-1.web.telegram.org" else "kws$dcId.web.telegram.org"
        val secondaryHost = if (isMedia) "kws$dcId.web.telegram.org" else "kws$dcId-1.web.telegram.org"
        val ips = dcDirectIps[dcId] ?: listOf("149.154.167.220")
        val worker = cleanWorkerHost(config.customWorkerHost)
        val workerScheme = if (config.workerDisableTls) "ws" else "wss"

        fun addWorkerRoutes() {
            if (worker.isNotEmpty()) {
                val targetIp = ips.first()
                routes += UpstreamRoute.WebSocketRoute(
                    key = "cf:$worker:$workerScheme:$dcId",
                    label = "Worker ${workerScheme.uppercase()} → DC$dcId",
                    url = "$workerScheme://$worker/apiws?dst=$targetIp",
                    isWorker = true
                )
                val altScheme = if (config.workerDisableTls) "wss" else "ws"
                routes += UpstreamRoute.WebSocketRoute(
                    key = "cf:$worker:$altScheme:$dcId",
                    label = "Worker ${altScheme.uppercase()} → DC$dcId",
                    url = "$altScheme://$worker/apiws?dst=$targetIp",
                    isWorker = true
                )
            }
        }

        when (config.routeMode) {
            RouteMode.WORKER_ONLY -> {
                addWorkerRoutes()
            }
            RouteMode.DIRECT_WS -> {
                routes += UpstreamRoute.WebSocketRoute("ws:$primaryHost", "WS $primaryHost", "wss://$primaryHost/apiws")
                routes += UpstreamRoute.WebSocketRoute("ws:$secondaryHost", "WS $secondaryHost", "wss://$secondaryHost/apiws")
                ips.forEach { ip ->
                    routes += UpstreamRoute.WebSocketRoute("ipws:$dcId:$ip", "IP-WS $ip (DC$dcId)", "wss://$primaryHost/apiws", fixedIp = ip)
                }
            }
            RouteMode.AUTO -> {
                // If user configured a personal Cloudflare Worker, prioritize it first!
                addWorkerRoutes()
                routes += UpstreamRoute.WebSocketRoute("ws:$primaryHost", "WS $primaryHost", "wss://$primaryHost/apiws")
                routes += UpstreamRoute.WebSocketRoute("ws:$secondaryHost", "WS $secondaryHost", "wss://$secondaryHost/apiws")
                ips.forEach { ip ->
                    routes += UpstreamRoute.WebSocketRoute("ipws:$dcId:$ip", "IP-WS $ip (DC$dcId)", "wss://$primaryHost/apiws", fixedIp = ip)
                }
                routes += UpstreamRoute.DirectTcpRoute("tcp:$dcId:${ips.first()}", "TCP443 ${ips.first()} (DC$dcId)", ips.first(), 443)
            }
        }

        val now = System.currentTimeMillis()
        val healthy = routes.filter { (routeCooldowns[it.key] ?: 0L) <= now }
        val cooling = routes.filter { (routeCooldowns[it.key] ?: 0L) > now }
        return healthy + cooling
    }

    private suspend fun handleClient(clientSocket: Socket, secret16: ByteArray, config: ProxyConfig) {
        val sid = sessionIdGen.incrementAndGet()
        val closed = AtomicBoolean(false)

        fun closeClient() {
            if (closed.compareAndSet(false, true)) {
                try {
                    clientSocket.close()
                } catch (_: Exception) {
                }
                activeSessions.remove(sid)
                ProxyStateStore.updateStats { it.copy(activeConnections = activeSessions.size) }
            }
        }

        try {
            clientSocket.soTimeout = 10_000
            val input = clientSocket.getInputStream()
            val init64 = readExact(input, 64) ?: run {
                closeClient()
                return
            }
            clientSocket.soTimeout = 0

            val hs = MtProtoCrypto.parseClientHandshake(init64, secret16)
            if (hs == null) {
                ProxyStateStore.log("WARN", "Отклонён неверный handshake (проверьте секрет в Telegram)")
                closeClient()
                return
            }

            val candidates = buildRoutes(hs.dcId, hs.isMedia, config)
            if (candidates.isEmpty()) {
                ProxyStateStore.log("ERR", "Нет доступных маршрутов (укажите Cloudflare Worker в настройках)")
                closeClient()
                return
            }

            var connected = false

            for (route in candidates) {
                if (!running.get() || clientSocket.isClosed) break
                val relay = MtProtoCrypto.buildRelayHandshake(hs.protoTag, hs.rawDcBytes)
                val startT = System.currentTimeMillis()

                when (route) {
                    is UpstreamRoute.WebSocketRoute -> {
                        val ws = tryOpenWebSocket(route, relay, hs, clientSocket, ::closeClient)
                        if (ws != null) {
                            connected = true
                            val ping = System.currentTimeMillis() - startT
                            val total = totalConnections.incrementAndGet()
                            activeSessions[sid] = {
                                try { ws.cancel() } catch (_: Exception) {}
                                closeClient()
                            }
                            ProxyStateStore.updateStats {
                                it.copy(
                                    activeConnections = activeSessions.size,
                                    totalConnections = total,
                                    lastRoute = route.label,
                                    lastPingMs = ping
                                )
                            }
                            ProxyStateStore.log("OK", "DC${hs.dcId}${if (hs.isMedia) "m" else ""} → ${route.label} (${ping} мс)")
                            pumpClientToWebSocket(input, hs, relay, ws, ::closeClient)
                            break
                        } else {
                            routeCooldowns[route.key] = System.currentTimeMillis() + 60_000L
                        }
                    }
                    is UpstreamRoute.DirectTcpRoute -> {
                        val upstream = tryOpenTcp(route.ip, route.port, relay.initPacket)
                        if (upstream != null) {
                            connected = true
                            val ping = System.currentTimeMillis() - startT
                            val total = totalConnections.incrementAndGet()
                            activeSessions[sid] = {
                                try { upstream.close() } catch (_: Exception) {}
                                closeClient()
                            }
                            ProxyStateStore.updateStats {
                                it.copy(
                                    activeConnections = activeSessions.size,
                                    totalConnections = total,
                                    lastRoute = route.label,
                                    lastPingMs = ping
                                )
                            }
                            ProxyStateStore.log("OK", "DC${hs.dcId} → ${route.label} (${ping} мс)")
                            pumpBidirectionalTcp(clientSocket, upstream, hs, relay, ::closeClient)
                            break
                        } else {
                            routeCooldowns[route.key] = System.currentTimeMillis() + 60_000L
                        }
                    }
                }
            }

            if (!connected) {
                ProxyStateStore.log("ERR", "DC${hs.dcId}: все маршруты недоступны")
                closeClient()
            }
        } catch (_: Exception) {
            closeClient()
        }
    }

    private suspend fun tryOpenWebSocket(
        route: UpstreamRoute.WebSocketRoute,
        relay: RelayHandshake,
        hs: ClientHandshake,
        clientSocket: Socket,
        onActiveSessionClosed: () -> Unit
    ): WebSocket? {
        val opened = CompletableDeferred<WebSocket?>()
        val isActive = AtomicBoolean(false)
        val clientOutLock = Any()
        val clientOut = clientSocket.getOutputStream()

        val client = if (route.fixedIp != null) {
            baseClient.newBuilder()
                .dns(object : Dns {
                    override fun lookup(hostname: String): List<InetAddress> =
                        listOf(InetAddress.getByName(route.fixedIp))
                })
                .build()
        } else {
            baseClient
        }

        val reqBuilder = Request.Builder()
            .url(route.url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/128.0.0.0 Mobile Safari/537.36")

        if (!route.isWorker) {
            reqBuilder
                .header("Sec-WebSocket-Protocol", "binary")
                .header("Origin", "https://web.telegram.org")
        }

        val ws = client.newWebSocket(reqBuilder.build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                isActive.set(true)
                webSocket.send(ByteString.of(*relay.initPacket))
                opened.complete(webSocket)
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                if (!isActive.get()) return
                try {
                    val raw = bytes.toByteArray()
                    val plain = relay.wsDecrypt.update(raw)
                    val enc = hs.clientEncrypt.update(plain)
                    synchronized(clientOutLock) {
                        clientOut.write(enc)
                        clientOut.flush()
                    }
                    val down = bytesDown.addAndGet(enc.size.toLong())
                    ProxyStateStore.updateStats { it.copy(bytesDown = down) }
                } catch (_: Exception) {
                    webSocket.cancel()
                    onActiveSessionClosed()
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (!opened.isCompleted) opened.complete(null)
                // Only close clientSocket if THIS route was the active relay!
                if (isActive.get()) onActiveSessionClosed()
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (!opened.isCompleted) {
                    val code = response?.code?.let { "HTTP $it" } ?: t.javaClass.simpleName
                    ProxyStateStore.log("WARN", "${route.label}: $code")
                    opened.complete(null)
                }
                // CRITICAL FIX: never close clientSocket if handshake failed — allow fallback to next route!
                if (isActive.get()) onActiveSessionClosed()
            }
        })

        return withTimeoutOrNull(4000L) { opened.await() } ?: run {
            ws.cancel()
            null
        }
    }

    private fun pumpClientToWebSocket(
        input: InputStream,
        hs: ClientHandshake,
        relay: RelayHandshake,
        ws: WebSocket,
        onClose: () -> Unit
    ) {
        val buf = ByteArray(16384)
        try {
            while (running.get()) {
                val read = input.read(buf)
                if (read <= 0) break
                val plain = hs.clientDecrypt.update(buf, 0, read)
                val enc = relay.wsEncrypt.update(plain)
                if (ws.queueSize() > 4 * 1024 * 1024) {
                    Thread.sleep(30)
                }
                if (!ws.send(ByteString.of(*enc))) break
                val up = bytesUp.addAndGet(read.toLong())
                ProxyStateStore.updateStats { it.copy(bytesUp = up) }
            }
        } catch (_: Exception) {
        } finally {
            try { ws.close(1000, "eof") } catch (_: Exception) {}
            onClose()
        }
    }

    private fun tryOpenTcp(ip: String, port: Int, initPacket: ByteArray): Socket? {
        return try {
            val s = Socket()
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(ip, port), 3000)
            s.getOutputStream().apply {
                write(initPacket)
                flush()
            }
            s
        } catch (_: Exception) {
            null
        }
    }

    private suspend fun pumpBidirectionalTcp(
        client: Socket,
        upstream: Socket,
        hs: ClientHandshake,
        relay: RelayHandshake,
        onClose: () -> Unit
    ) = coroutineScope {
        val j1 = launch(Dispatchers.IO) {
            val buf = ByteArray(16384)
            val inp = client.getInputStream()
            val out = upstream.getOutputStream()
            try {
                while (running.get()) {
                    val n = inp.read(buf)
                    if (n <= 0) break
                    val plain = hs.clientDecrypt.update(buf, 0, n)
                    val enc = relay.wsEncrypt.update(plain)
                    out.write(enc)
                    out.flush()
                    val up = bytesUp.addAndGet(n.toLong())
                    ProxyStateStore.updateStats { it.copy(bytesUp = up) }
                }
            } catch (_: Exception) {
            } finally {
                try { upstream.close() } catch (_: Exception) {}
                onClose()
            }
        }
        val j2 = launch(Dispatchers.IO) {
            val buf = ByteArray(16384)
            val inp = upstream.getInputStream()
            val out = client.getOutputStream()
            try {
                while (running.get()) {
                    val n = inp.read(buf)
                    if (n <= 0) break
                    val plain = relay.wsDecrypt.update(buf, 0, n)
                    val enc = hs.clientEncrypt.update(plain)
                    out.write(enc)
                    out.flush()
                    val down = bytesDown.addAndGet(n.toLong())
                    ProxyStateStore.updateStats { it.copy(bytesDown = down) }
                }
            } catch (_: Exception) {
            } finally {
                try { upstream.close() } catch (_: Exception) {}
                onClose()
            }
        }
        joinAll(j1, j2)
    }

    private fun readExact(input: InputStream, size: Int): ByteArray? {
        val out = ByteArray(size)
        var offset = 0
        while (offset < size) {
            val n = input.read(out, offset, size - offset)
            if (n <= 0) return null
            offset += n
        }
        return out
    }

    fun runDiagnostics(config: ProxyConfig) {
        scope.launch {
            val worker = cleanWorkerHost(config.customWorkerHost)
            val pending = mutableListOf(
                DiagnosticItem("Локальный порт 127.0.0.1:${config.port}", DiagStatus.PENDING, "Проверка...")
            )
            if (worker.isNotEmpty()) {
                pending += DiagnosticItem("Cloudflare Worker (WSS)", DiagStatus.PENDING, "Проверка $worker...")
                pending += DiagnosticItem("Cloudflare Worker (WS порт 80)", DiagStatus.PENDING, "Проверка без TLS...")
            }
            pending += DiagnosticItem("WebSocket DC2 (kws2)", DiagStatus.PENDING, "Проверка...")
            pending += DiagnosticItem("WebSocket DC4 (kws4)", DiagStatus.PENDING, "Проверка...")
            pending += DiagnosticItem("IP-обход DNS (149.154.167.220)", DiagStatus.PENDING, "Проверка...")

            ProxyStateStore.updateStats {
                it.copy(
                    diagnosticsRunning = true,
                    diagnosticVerdict = null,
                    diagnostics = pending
                )
            }
            ProxyStateStore.log("INFO", "Запущена проверка маршрутов...")

            val results = mutableListOf<DiagnosticItem>()

            val localRes = if (running.get()) {
                try {
                    val t0 = System.currentTimeMillis()
                    Socket().use { s -> s.connect(InetSocketAddress("127.0.0.1", config.port), 1000) }
                    DiagnosticItem("Локальный порт 127.0.0.1:${config.port}", DiagStatus.OK, "Слушает и отвечает", System.currentTimeMillis() - t0)
                } catch (e: Exception) {
                    DiagnosticItem("Локальный порт 127.0.0.1:${config.port}", DiagStatus.FAIL, "Нет ответа: ${e.message}")
                }
            } else {
                DiagnosticItem("Локальный порт 127.0.0.1:${config.port}", DiagStatus.WARN, "Прокси сейчас выключен")
            }
            results += localRes

            var workerWssOk = false
            var workerWsOk = false
            if (worker.isNotEmpty()) {
                val wWss = probeWs("Cloudflare Worker (WSS)", "wss://$worker/apiws?dst=149.154.167.220", null, isWorker = true)
                val wWs = probeWs("Cloudflare Worker (WS порт 80)", "ws://$worker/apiws?dst=149.154.167.220", null, isWorker = true)
                workerWssOk = wWss.status == DiagStatus.OK
                workerWsOk = wWs.status == DiagStatus.OK
                results += wWss
                results += wWs
            }

            val dc2 = probeWs("WebSocket DC2 (kws2)", "wss://kws2.web.telegram.org/apiws", null, isWorker = false)
            val dc4 = probeWs("WebSocket DC4 (kws4)", "wss://kws4.web.telegram.org/apiws", null, isWorker = false)
            val ipWs = probeWs("IP-обход DNS (149.154.167.220)", "wss://kws4.web.telegram.org/apiws", "149.154.167.220", isWorker = false)
            results += dc2
            results += dc4
            results += ipWs

            val directOk = dc2.status == DiagStatus.OK || dc4.status == DiagStatus.OK || ipWs.status == DiagStatus.OK

            val verdict = when {
                workerWssOk -> "Отлично! Твой Cloudflare Worker (WSS) пробивает блокировку — Telegram будет работать стабильно."
                workerWsOk -> "Worker отвечает без TLS (порт 80)! Включи тумблер «Без TLS для Worker» в Настройках."
                directOk -> "Прямой WebSocket доступен в этой сети — можно работать даже без Worker."
                worker.isEmpty() -> "Прямые IP Telegram заблокированы этим провайдером. Добавь свой бесплатный Cloudflare Worker в Настройках (или проверь на 4G)."
                else -> "Провайдер блокирует и прямые IP, и workers.dev. Попробуй переключить Wi-Fi ↔ 4G."
            }

            ProxyStateStore.log("INFO", "Проверка завершена: $verdict")
            ProxyStateStore.updateStats {
                it.copy(
                    diagnosticsRunning = false,
                    diagnostics = results,
                    diagnosticVerdict = verdict
                )
            }
        }
    }

    private suspend fun probeWs(title: String, url: String, fixedIp: String?, isWorker: Boolean): DiagnosticItem {
        val t0 = System.currentTimeMillis()
        val deferred = CompletableDeferred<DiagnosticItem>()
        val client = if (fixedIp != null) {
            baseClient.newBuilder()
                .dns(object : Dns {
                    override fun lookup(hostname: String): List<InetAddress> =
                        listOf(InetAddress.getByName(fixedIp))
                })
                .build()
        } else {
            baseClient
        }

        val rb = Request.Builder().url(url)
        if (!isWorker) {
            rb.header("Sec-WebSocket-Protocol", "binary")
                .header("Origin", "https://web.telegram.org")
        }

        val ws = client.newWebSocket(rb.build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val ms = System.currentTimeMillis() - t0
                webSocket.close(1000, "probe")
                deferred.complete(DiagnosticItem(title, DiagStatus.OK, "Handshake OK", ms))
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val reason = response?.code?.let { "HTTP $it" } ?: (t.message?.take(38) ?: "Таймаут")
                deferred.complete(DiagnosticItem(title, DiagStatus.FAIL, reason))
            }
        })

        return withTimeoutOrNull(4000L) { deferred.await() } ?: run {
            ws.cancel()
            DiagnosticItem(title, DiagStatus.FAIL, "Таймаут > 4с")
        }
    }
}
